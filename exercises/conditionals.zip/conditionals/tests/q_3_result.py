
test = {
  'name': 'Question 3_y',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> # pou need to set the value for 'result'
          >>> 'result' in vars()
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> result == 'a divided by 6 is 4'
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
