test = {
  'name': 'Question 4_increase',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> increase(2, 3)
          13
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> increase(-3, 9)
          21
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
