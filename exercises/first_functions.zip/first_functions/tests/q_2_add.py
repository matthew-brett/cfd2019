test = {
  'name': 'Question 2_add',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> add(2, 3)
          5
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> add(3, -1)
          2
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
