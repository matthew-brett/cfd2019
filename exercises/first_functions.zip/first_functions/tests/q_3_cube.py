test = {
  'name': 'Question 3_cube',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> cube(3)
          27
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> cube(5)
          125
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
