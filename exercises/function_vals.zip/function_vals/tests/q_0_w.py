test = {
  'name': 'Question 0_w',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> w == 7
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> func_a is add
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
