test = {
  'name': 'Question 3_z',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> z == 4
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> another_func is add
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
