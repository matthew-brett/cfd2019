test = {
  'name': 'Question 1_x',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> x == 2
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> func_b is sub
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
