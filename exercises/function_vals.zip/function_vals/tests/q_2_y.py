
test = {
  'name': 'Question 2_y',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> y == 12
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> my_func1 is sub
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> my_func2 is add
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
